# config.py

BASE_URL = "https://pruebas.siata.gov.co/api/v1"

API_TOKEN = "cd869adc-f556-4eb0-a80a-44250180a841"
